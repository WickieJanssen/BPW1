using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DialogueIceMan1 : MonoBehaviour
{
    int dialogueInt;
    public Text dialogue;
    public Text button;
    public Text button1;

    public AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (dialogueInt == 0)
        {
            dialogue.text = "ARGGGHHH! How can such a massive stranger win from ME?! You were lucky.";
            button.text = "Can I now know where the keys are?!";
            button1.text = "Am I really that fat?";
        }
        if (dialogueInt == 1)
        {
            dialogue.text = "Well, now you may have the knowledge of where the keys will be. In my pockets or not in my pockets.";
            button.text = "Just give them to me";
            button1.text = "Why are you talking like that";
        }
        if (dialogueInt == 2)
        {
            dialogue.text = "Ah I understand. I don't have it on me, or maybe I have it on me.";
            button.text = "Just tell me";
            button1.text = "Just tell me please";
        }
        if (dialogueInt == 3)
        {
            dialogue.text = "Well, I don't have them I just wanted a SNOWBALL FIGHTtTtT!!!";
            button.text = "YOU ARE A WASTE OF AIR YOU � ";
            button1.text = "Yep bye";
        }
        if (dialogueInt == 4)
        {
            dialogue.text = "Stop! Maybe you can ask the great poet, I mean pirate man.";
            button.text = "Who?";
            button1.text = "Poet and pirate?";
        }
        if (dialogueInt == 5)
        {
            dialogue.text = "He is by the water, he's got a small boat, can't miss him.";
            button.text = "Ok bye bye.";
            button1.text = "I am big and the boat is small?";
        }
        if (dialogueInt == 6)
        {
            SceneManager.LoadScene("City2");
        }
    }

    public void Buttons()
    {
        dialogueInt += 1;
        audioSource.Play();
    }
}

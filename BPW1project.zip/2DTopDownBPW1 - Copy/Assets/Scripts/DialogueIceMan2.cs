using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DialogueIceMan2 : MonoBehaviour
{
    int dialogueInt;
    public Text dialogue;
    public Text button;
    public Text button1;

    public AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (dialogueInt == 0)
        {
            dialogue.text = "Brr� So cold. Ah! There are you again�";
            button.text = "It's me";
            button1.text = "Yep, again.";
        }
        if (dialogueInt == 1)
        {
            dialogue.text = "AND NOW WITH A FISH! Well, thanks colossal stranger.";
            button.text = "Yep";
            button1.text = "I really am fat";
        }
        if (dialogueInt == 2)
        {
            dialogue.text = "Okay, open your mouuthhh. Here comes the plane";
            button.text = "It AlReAdY OpEn";
            button1.text = "No, why?";
        }
        if (dialogueInt == 3)
        {
            dialogue.text = "No not you immense stranger. 'SmAcK' 'The polar bears head nods'";
            button.text = "You are alive?";
            button1.text = "IT'S ALIVE!!!";
        }
        if (dialogueInt == 4)
        {
            dialogue.text = "'He seems to enjoy the fish' 'He spits some sort of game machine out of his mouth'";
            button.text = "Okay.";
            button1.text = "What do you mean?";
        }
        if (dialogueInt == 5)
        {
            dialogue.text = "'He nods at the picture of Alicia Keys and the game machine'";
            button.text = "Have you got the keys in your head?";
            button1.text = "Have you got Alicia Keys in your head?";
        }
        if (dialogueInt == 6)
        {
            dialogue.text = "'The polar bear heads nods diagonally'";
            button.text = "Do you mean maybe?";
            button1.text = "Who nods diagonally?";
        }
        if (dialogueInt == 7)
        {
            dialogue.text = "'He nods again at the game machine' 'It has a racing game on it and the highscore is quite high'";
            button.text = "Do you want me to play?";
            button1.text = "No, no, no.";
        }
        if (dialogueInt == 8)
        {
            dialogue.text = "'Just not enough point for the unicorn ice car'";
            button.text = "Okay I trade the ice car for the keys.";
            button1.text = "Yep";
        }
        if (dialogueInt == 9)
        {
            SceneManager.LoadScene("RacingExplanation");
        }
    }

    public void Buttons()
    {
        dialogueInt += 1;
        audioSource.Play();
    }
}

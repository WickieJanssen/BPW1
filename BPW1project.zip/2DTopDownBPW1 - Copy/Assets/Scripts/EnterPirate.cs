using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class EnterPirate : MonoBehaviour
{
    public Text text;
    private float coolDown = 3;
    private bool hit;
    public bool canEnter;

    void Update()
    {
        if (canEnter)
        {
            if (hit)
            {
                coolDown -= Time.deltaTime;
            }
            if (coolDown <= 0)
            {
                SceneManager.LoadScene("PirateTalk");
            }
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (canEnter)
        {
            if (collision.name == "Player")
            {
                hit = true;

            }
        }
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (canEnter)
        {
            text.text = "Talking to the Pirate in: " + (int)coolDown;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (canEnter)
        {
            hit = false;
            coolDown = 3;
            if (collision.name == "Player")
            {
                text.text = "";
            }
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SnowBallDamage : MonoBehaviour
{
    private float y;
    private float x;
    public float ySpeed;

    private float coolDown;
    public float coolDownTime;

    void Update()
    {
        coolDown += Time.deltaTime;
        if (coolDown > coolDownTime)
        {
            y -= ySpeed;
        }
        if (y < -12)
        {
            y = 12;
            coolDown = 0;
            x = Random.Range(-3, 3);
        }
        transform.position = new Vector3(x, y, transform.position.z);
    }
}

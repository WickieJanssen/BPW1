using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class DialogueGardener : MonoBehaviour
{
    int dialogueInt;
    public Text dialogue;
    public Text button;
    public Text button1;

    public AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (dialogueInt == 0)
        {
            dialogue.text = "Hello stranger! I found you on the bridge, are you alright?";
            button.text = "Yep";
            button1.text = "No";
        }
        if (dialogueInt == 1)
        {
            dialogue.text = "Well you can always stay, but I think you want to go home right?";
            button.text = "Yep";
            button1.text = "Home?";
        }
        if (dialogueInt == 2)
        {
            dialogue.text = "We like the silence around here so the gate is always closed.";
            button.text = "Okay";
            button1.text = "Yepo?";
        }
        if (dialogueInt == 3)
        {
            dialogue.text = " You can ask the Major if he wants to open the gate for you.";
            button.text = "Okay";
            button1.text = "Let'sssss gooo";
        }
        if (dialogueInt == 4)
        {
            dialogue.text = "He lives in the house with the red hat on the roof, but watch out he is kind of a StRaNggEee man Ha Ha!";
            button.text = "On my way";
            button1.text = "OMW!";
        }
        if (dialogueInt == 5)
        {
            SceneManager.LoadScene("City");
        }
    }

    public void Buttons()
    {
        dialogueInt += 1;
        audioSource.Play();
    }
}

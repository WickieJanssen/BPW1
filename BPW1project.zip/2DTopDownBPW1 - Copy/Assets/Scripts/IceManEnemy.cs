using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class IceManEnemy : MonoBehaviour
{
    public Rigidbody2D rb;
    private Vector2 target;
    public float moveSpeed;
    private int lives = 3;

    public bool hit;
    private float coolDown;
    public float coolDownTime;
    public Image hart;
    public Image hart1;
    public Image hart2;
    public Sprite greyHart;

    private float deadCoolDown;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        target = new Vector2(0, -4);
    }

    // Update is called once per frame
    void Update()
    {
        if(Vector2.Distance(rb.position, target)<1)
        {
            target = new Vector2(Random.Range(-10f,10f), Random.Range(-10f, 10f));
        }
        Vector2 newPosition = Vector2.MoveTowards(transform.position, target, Time.deltaTime * moveSpeed);
        rb.MovePosition(newPosition);

        if (lives == 2)
        {
            hart2.sprite = greyHart;
        }
        if (lives == 1)
        {
            hart1.sprite = greyHart;
        }
        if (lives == 0)
        {
            hart.sprite = greyHart;
            deadCoolDown += Time.deltaTime;
        }
        if (deadCoolDown > 2)
        {
            SceneManager.LoadScene("IceManHouse1");
        }
        if (hit)
        {
            coolDown += Time.deltaTime;
        }
        if (coolDown > coolDownTime)
        {
            coolDown = 0;
            hit = false;
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        
        if(collision.tag == "SnowBall")
        {
            if(!hit)
            {
                lives -= 1;
                hit = true;
            }
        }
    }
}

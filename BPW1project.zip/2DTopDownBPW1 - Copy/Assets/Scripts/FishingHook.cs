using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class FishingHook : MonoBehaviour
{
    public Rigidbody2D rb;

    private float y;
    public float moveSpeed;
    private bool fishing=true;
    private float x;

    private int playerLives = 3;
    private int fishLives = 3;

    private float coolDown;
    public float coolDownTime;
    private bool hit;

    private float beginCoolDown;
    private float beginCoolDownTime = 1;

    public Image hartPlayer;
    public Image hartPlayer1;
    public Image hartPlayer2;
    public Image hartFish;
    public Image hartFish1;
    public Image hartFish2;
    public Sprite greyHart;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        if (beginCoolDown < beginCoolDownTime)
        {
            beginCoolDown += Time.deltaTime;
        }

        if (Input.GetButtonDown("Fire1") && !fishing)
        {
            fishing = true;
        }
        if (fishing)
        {
            y -= moveSpeed;
        }
        else
        {
            x = Input.GetAxisRaw("Horizontal") * 6;
        }
        if (y < -4)
        {
            moveSpeed = -moveSpeed * 4;
        }
        if (y > 14)
        {
            y = 14;
            moveSpeed = -moveSpeed / 4;
            fishing = false;
        }

        if (hit)
        {
            coolDown += Time.deltaTime;
        }
        if (coolDown > coolDownTime)
        {
            coolDown = 0;
            hit = false;
        }

        if (playerLives == 2)
        {
            hartPlayer2.sprite = greyHart;
        }
        if (playerLives == 1)
        {
            hartPlayer1.sprite = greyHart;
        }
        if (playerLives == 0)
        {
            hartPlayer.sprite = greyHart;
            SceneManager.LoadScene("RestartFishing");
        }

        if (fishLives == 2)
        {
            hartFish2.sprite = greyHart;
        }
        if (fishLives == 1)
        {
            hartFish1.sprite = greyHart;
        }
        if (fishLives == 0)
        {
            hartFish.sprite = greyHart;
            SceneManager.LoadScene("PirateTalk1");
        }
    }
    void FixedUpdate()
    {
        rb.MovePosition(new Vector2(x, y));
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (beginCoolDown > beginCoolDownTime)
        {
            if (collision.tag == "Fish")
            {
                if (!hit)
                {
                    playerLives -= 1;
                    hit = true;
                }
            }
            if (collision.name == "GoodFish")
            {
                if (!hit)
                {
                    fishLives -= 1;
                    hit = true;
                }
            }
        }
    }
}

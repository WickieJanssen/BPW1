using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DialogueIceMan3 : MonoBehaviour
{
    int dialogueInt;
    public Text dialogue;
    public Text button;
    public Text button1;

    public AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (dialogueInt == 0)
        {
            dialogue.text = "'The polar bear nods diagonally, vertical and horizontal'";
            button.text = "How can you nod al those ways.";
            button1.text = "Yep, here you go.";
        }
        if (dialogueInt == 1)
        {
            dialogue.text = "'He spits out the keys'";
            button.text = "WOWWW THERE THEY ARE";
            button1.text = "NOT ALICIA KEYS?!";
        }
        if (dialogueInt == 2)
        {
            dialogue.text = "Oh the keys! Now you can go home! I actually started to like you.";
            button.text = "Yeah, me too.";
            button1.text = "Yep";
        }
        if (dialogueInt == 3)
        {
            dialogue.text = "Well bye then, mammoth sized human.";
            button.text = "OK BYE!";
            button1.text = "REALLY MAMMOTH?!";
        }
        if (dialogueInt == 4)
        {
            SceneManager.LoadScene("WinScreen");
        }
    }

    public void Buttons()
    {
        dialogueInt += 1;
        audioSource.Play();
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fish : MonoBehaviour
{
    public Rigidbody2D rb;
    public SpriteRenderer spriteRenderer;

    private float x;
    public float swimSpeed;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        x = transform.position.x;
    }

    // Update is called once per frame
    void Update()
    {
        x += swimSpeed;

        if (x > 10)
        {
            swimSpeed = -swimSpeed;
            spriteRenderer.flipX = !spriteRenderer.flipX;
            
        }
        if (x < -10)
        {
            swimSpeed = -swimSpeed;
            spriteRenderer.flipX = !spriteRenderer.flipX;
        }
    }
    void FixedUpdate()
    {
        rb.MovePosition(new Vector2(x, transform.position.y));
    }
}

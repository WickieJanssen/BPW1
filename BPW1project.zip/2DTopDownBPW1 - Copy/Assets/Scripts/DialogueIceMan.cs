using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DialogueIceMan : MonoBehaviour
{
    int dialogueInt;
    public Text dialogue;
    public Text button;
    public Text button1;

    public AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (dialogueInt == 0)
        {
            dialogue.text = "Brr� So cold. Oh, I was waiting for you and your extreme hat mister� 'Glup'";
            button.text = "Waiting for me?!";
            button1.text = "Extreme?!";
        }
        if (dialogueInt == 1)
        {
            dialogue.text = "Oh sorry, I thought you were someone else. Well, who are you?!";
            button.text = "I am a stranger and �";
            button1.text = "I am a huge stranger and �";
        }
        if (dialogueInt == 2)
        {
            dialogue.text = "Ah, I understand. I don't have it on me, or maybe I have it on me.";
            button.text = "Just tell me";
            button1.text = "Just tell me please";
        }
        if (dialogueInt == 3)
        {
            dialogue.text = "Maybe my memory will be clear after a SNOWBALL FIGHTtTtT!!!";
            button.text = "Oh no � ";
            button1.text = "How old are we?!";
        }
        if (dialogueInt == 4)
        {
            SceneManager.LoadScene("SnowballExplanation");
        }
    }

    public void Buttons()
    {
        dialogueInt += 1;
        audioSource.Play();
    }
}

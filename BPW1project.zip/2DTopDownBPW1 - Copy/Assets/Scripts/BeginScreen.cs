using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BeginScreen : MonoBehaviour
{
    public void start()
    {
        SceneManager.LoadScene("GardenHouse");
    }
    public void exit()
    {
        Application.Quit();
    }
}

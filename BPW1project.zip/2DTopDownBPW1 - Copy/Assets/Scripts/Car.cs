using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Car : MonoBehaviour
{
    public float carSpeed;
    public Transform player;
    public GameObject car;
    public GameObject playerCar;
    PlayerMovement playerMovement;

    private void Start()
    {
        playerMovement = FindObjectOfType<PlayerMovement>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.name == "Player")
        {
            playerMovement.runSpeed = carSpeed;
            player.position = new Vector3(transform.position.x, player.position.y, player.position.z);
            playerCar.SetActive(true);
            Destroy(car);
        }
    }
}

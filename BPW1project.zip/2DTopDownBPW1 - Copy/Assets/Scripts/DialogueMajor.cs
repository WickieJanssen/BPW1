using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DialogueMajor : MonoBehaviour
{
    int dialogueInt;
    public Text dialogue;
    public Text button;
    public Text button1;

    public AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (dialogueInt == 0)
        {
            dialogue.text = "Hehehe I am just done washing my � ";
            button.text = "Hands";
            button1.text = "Hat";
        }
        if (dialogueInt == 1)
        {
            dialogue.text = "oh! I thought you were someone else. We don't get so many visitors.";
            button.text = "You don't?";
            button1.text = "Ofcourse not";
        }
        if (dialogueInt == 2)
        {
            dialogue.text = "I am always wondering why? Anyways how are you stranger?";
            button.text = "Good but � ";
            button1.text = "StRaNggEee but �";
        }
        if (dialogueInt == 3)
        {
            dialogue.text = "Ohh well what a story! Uhm Yeah I will open the gate for you of course!.";
            button.text = "Thanks mister Major";
            button1.text = "Yep";
        }
        if (dialogueInt == 4)
        {
            dialogue.text = "'Glup' By the hundred hats or more, I can't seem to find my keys! Oh! I found them.";
            button.text = "That�s just a picture of Alicia Keys�";
            button1.text = "A a a Alicia K k k Keysss";
        }
        if (dialogueInt == 5)
        {
            dialogue.text = "Oh! This is just a picture of Alicia Keys. For the high hats sake, where are my keys?!";
            button.text = "I dont know";
            button1.text = "Can I go to home now";
        }
        if (dialogueInt == 6)
        {
            dialogue.text = "Well, can you maybe help search for my keys, big stranger?";
            button.text = "Yep";
            button1.text = "Are you calling me fat?";
        }
        if (dialogueInt == 7)
        {
            dialogue.text = "Well, thanks humongous stranger, maybe you can ask my lover. I mean neighbor! He lives in an ice house, you cannot miss it!";
            button.text = "Hehe you are in love hehe";
            button1.text = "Are you calling me fat? AGAIN?!";
        }
        if (dialogueInt == 8)
        {
            dialogue.text = "Thanks stranger, I will continue washing my �Uhm, Hat. Bye!";
            button.text = "You just don�t listen, he?";
            button1.text = "Ok bye.";
        }
        if (dialogueInt == 9)
        {
            SceneManager.LoadScene("City1");
        }
    }

    public void Buttons()
    {
        dialogueInt += 1;
        audioSource.Play();
    }
}

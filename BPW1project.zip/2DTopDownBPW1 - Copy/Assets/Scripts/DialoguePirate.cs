using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DialoguePirate : MonoBehaviour
{
    int dialogueInt;
    public Text dialogue;
    public Text button;
    public Text button1;

    public AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (dialogueInt == 0)
        {
            dialogue.text = "FROM off a hill whose concave womb reworded� I mean ARR! Wow, who ARR you if I may ask?";
            button.text = "A enormous stranger apparently";
            button1.text = "Are you a poetpirate? Poep for short.";
        }
        if (dialogueInt == 1)
        {
            dialogue.text = "You ARR who you are and I am who I am. What ARR you doing in such a fairy land if I may ask?";
            button.text = "I am looking for keys, no not alicia keys�";
            button1.text = "Fairy land? I am�";
        }
        if (dialogueInt == 2)
        {
            dialogue.text = "'Gulp' He lost the keys again ?! His youthful hose, well saved, a world too wide. I mean ARRgg";
            button.text = "Well maybe you can sail me away?";
            button1.text = "Boat go tsjoeke tsjoeke, please?";
        }
        if (dialogueInt == 3)
        {
            dialogue.text = "Well, as you may have noticed the water stops at the walls.";
            button.text = "Yep";
            button1.text = "I have eyes yes";
        }
        if (dialogueInt == 4)
        {
            dialogue.text = "And we ARR over nine thousand feet up in the air. As you can see through the holes in the wall.";
            button.text = "OVER NINE THOUSAND?!";
            button1.text = "HOLES IN THE WALL?";
        }
        if (dialogueInt == 5)
        {
            dialogue.text = "Well, yes. But maybe I can help you, if you help me first.";
            button.text = "Yep";
            button1.text = "Oh no, not again";
        }
        if (dialogueInt == 6)
        {
            dialogue.text = "I need a fish for the Major's lover� I mean the ice king's polar bear.";
            button.text = "But that is only a head right?";
            button1.text = "King of what?";
        }
        if (dialogueInt == 7)
        {
            dialogue.text = "Nice of you to give me a hand. Come, hop on my boat.";
            button.text = "WHY DOES NOBODY EVER LISTEN???";
            button1.text = "I don't have a choice, right?!";
        }
        if (dialogueInt == 8)
        {
            SceneManager.LoadScene("FishingExplanation");
        }
    }

    public void Buttons()
    {
        dialogueInt += 1;
        audioSource.Play();
    }
}

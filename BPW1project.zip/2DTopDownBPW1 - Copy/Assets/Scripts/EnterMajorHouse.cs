using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class EnterMajorHouse : MonoBehaviour
{
    public Text text;
    private float coolDown = 3;
    private bool hit;
    public bool canEnter;

    PositionManager positionManager;

    void Start()
    {
        positionManager = FindObjectOfType<PositionManager>();
    }
    void Update()
    {
        if (canEnter)
        {
            if (hit)
            {
                coolDown -= Time.deltaTime;
            }
            if (coolDown <= 0)
            {
                positionManager.major = true;
                SceneManager.LoadScene("MajorHouse");
            }
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (canEnter)
        {
            if (collision.name == "Player")
            {
                hit = true;

            }
        }
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (canEnter)
        {
            text.text = "Entering the Major's house in: " + (int)coolDown;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (canEnter)
        {
            hit = false;
            coolDown = 3;
            if (collision.name == "Player")
            {
                text.text = "";
            }
        }
    }
}

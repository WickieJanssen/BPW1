using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Road : MonoBehaviour
{
    public Rigidbody2D rb;
    private float y;
    public float moveSpeed;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        y = transform.position.y;
    }

    // Update is called once per frame
    void Update()
    {
        y -= moveSpeed;
        if (y <= -10.09f)
        {
            y = 10.09f;
        }
    }
    void FixedUpdate()
    {
        rb.MovePosition(new Vector2(transform.position.x, y));
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpAndDownAnimation : MonoBehaviour
{
    private float y;
    public float pos;
    public float animationSpeed;
    public float maxHeight;
    public float minHeight;
    public bool scale;
    public bool position;

    // Start is called before the first frame update
    void Start()
    {
        y = pos;
    }

    // Update is called once per frame
    void Update()
    {
        y += animationSpeed;
        if (y > maxHeight)
        {
            animationSpeed = -animationSpeed;
        }
        if(y < minHeight)
        {
            animationSpeed = -animationSpeed;
        }
        if (scale)
        {
            transform.localScale = new Vector3(transform.localScale.x, y, transform.localScale.z);
        }
        if (position)
        {
            transform.position = new Vector3(transform.position.x, y, transform.position.z);
        }
    }
}

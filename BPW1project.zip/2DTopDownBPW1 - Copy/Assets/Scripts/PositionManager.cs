using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PositionManager : MonoBehaviour
{
    public Transform player;

    public Vector3 majorHouse;
    public Vector3 iceManHouse;
    public Vector3 pirateTalk;

    public bool major;
    public bool iceMan;
    public bool pirate;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (major)
        {
            player.position = majorHouse;
        }
        if (iceMan)
        {
            player.position = iceManHouse;
        }
        if (pirate)
        {
            player.position = pirateTalk;
        }
    }
}

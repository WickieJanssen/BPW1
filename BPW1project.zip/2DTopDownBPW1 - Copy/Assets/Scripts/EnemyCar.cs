using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyCar : MonoBehaviour
{
    public Rigidbody2D rb;
    private float x;
    private float y;
    public float moveSpeed;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        y -= moveSpeed;
        if (y <= -12)
        {
            moveSpeed += 0.001f;
            y = 12;
            x = Random.Range(-7, 7);
        }
    }

    void FixedUpdate()
    {
        rb.MovePosition(new Vector2(x, y));
    }
}

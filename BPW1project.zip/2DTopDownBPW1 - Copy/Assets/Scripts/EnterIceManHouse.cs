using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class EnterIceManHouse : MonoBehaviour
{
    public Text text;
    private float coolDown = 3;
    private bool hit;
    public bool canEnter;
    public string house;

    void Update()
    {
        if (canEnter)
        {
            if (hit)
            {
                coolDown -= Time.deltaTime;
            }
            if (coolDown <= 0)
            {
                SceneManager.LoadScene(house);
            }
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (canEnter)
        {
            if (collision.name == "Player")
            {
                hit = true;

            }
        }
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (canEnter)
        {
            text.text = "Entering the Ice Man's house in: " + (int)coolDown;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (canEnter)
        {
            hit = false;
            coolDown = 3;
            if (collision.name == "Player")
            {
                text.text = "";
            }
        }
    }
}

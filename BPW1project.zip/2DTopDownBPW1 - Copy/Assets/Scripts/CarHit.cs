using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class CarHit : MonoBehaviour
{
    public bool hit;
    private float coolDown;
    public float coolDownTime;

    private int lives = 3;
    public Image hart;
    public Image hart1;
    public Image hart2;
    public Sprite greyHart;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (hit)
        {
            coolDown += Time.deltaTime;
        }
        if (coolDown > coolDownTime)
        {
            coolDown = 0;
            hit = false;
        }

        if (lives == 2)
        {
            hart2.sprite = greyHart;
        }
        if (lives == 1)
        {
            hart1.sprite = greyHart;
        }
        if (lives == 0)
        {
            SceneManager.LoadScene("RestartRacing");
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.name == "EnemyCar")
        {
            if (!hit)
            {
                lives -= 1;
                hit = true;
            }
        }
    }
}

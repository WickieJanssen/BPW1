using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DialoguePirate1 : MonoBehaviour
{
    int dialogueInt;
    public Text dialogue;
    public Text button;
    public Text button1;

    public AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (dialogueInt == 0)
        {
            dialogue.text = "YOU ACTUALLY DID IT! YOU CAUGHT A FISH.";
            button.text = "Yep";
            button1.text = "Yepo?";
        }
        if (dialogueInt == 1)
        {
            dialogue.text = "Well, can you give it to the Major's love� I mean the ice king.";
            button.text = "Already going";
            button1.text = "yep, ok bye.";
        }
        if (dialogueInt == 2)
        {
            SceneManager.LoadScene("City3");
        }
    }

    public void Buttons()
    {
        dialogueInt += 1;
        audioSource.Play();
    }
}

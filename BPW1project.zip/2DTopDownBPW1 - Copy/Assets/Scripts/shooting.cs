using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shooting : MonoBehaviour
{
    public Rigidbody2D bulletPrefab;
    public float attackSpeed = 0.5f;
    public float coolDown;
    public float bulletSpeed = 500;
    public float yValue = 1f;
    public float xValue = 0.2f;

    public CameraShake cameraShake;

    // Update is called once per frame
    void Update()
    {
        if (Time.time >= coolDown)
        {
            if (Input.GetMouseButton(0))
            {
                Fire();
                StartCoroutine(cameraShake.shake(.05f, .2f));
            }
        }
    }

    void Fire()
    {
        Rigidbody2D bPrefab = Instantiate(bulletPrefab, new Vector3(transform.position.x + xValue, transform.position.y + yValue, transform.position.z), transform.rotation) as Rigidbody2D;

        bPrefab.GetComponent<Rigidbody2D>().AddForce(transform.up * bulletSpeed);

        coolDown = Time.time + attackSpeed;
    }
}

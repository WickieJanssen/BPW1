using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TreeSnow : MonoBehaviour
{
    public SpriteRenderer spriteRenderer;
    public Sprite snowTree;
    void Start()
    {
        spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "SnowBall")
        {
            spriteRenderer.sprite = snowTree;
        }
    }
}

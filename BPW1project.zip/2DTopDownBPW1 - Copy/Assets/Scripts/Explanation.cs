using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Explanation : MonoBehaviour
{
    public string scene;

    public void button()
    {
        SceneManager.LoadScene(scene);
    }
}

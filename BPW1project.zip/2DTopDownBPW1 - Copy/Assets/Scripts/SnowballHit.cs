using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SnowballHit : MonoBehaviour
{
    public bool hit;
    private float coolDown;
    public float coolDownTime;

    private int lives = 3;
    public Image hart;
    public Image hart1;
    public Image hart2;
    public Sprite greyHart;

    private float deadCoolDown;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (hit)
        {
            coolDown += Time.deltaTime;
        }
        if (coolDown > coolDownTime)
        {
            coolDown = 0;
            hit = false;
        }

        if (lives == 2)
        {
            hart2.sprite = greyHart;
        }
        if (lives == 1)
        {
            hart1.sprite = greyHart;
        }
        if (lives == 0)
        {
            hart.sprite = greyHart;
            deadCoolDown += Time.deltaTime;
        }
        if (deadCoolDown > 2)
        {
            SceneManager.LoadScene("Restart");
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "SnowBallPlayer")
        {
            if (!hit)
            {
                lives -= 1;
                hit = true;
            }
        }
    }
}

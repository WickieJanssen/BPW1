using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class RacingUI : MonoBehaviour
{
    public Text highScore;
    private float hs;
    private int hsint;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        hs += 0.01f;
        hsint = (int)hs;
        highScore.text = "HighScore: "+ hsint;
        if (hs >= 200)
        {
            SceneManager.LoadScene("IceManHouse3");
        }
    }
}
